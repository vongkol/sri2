<?php $__env->startSection('content'); ?>   
<link href="<?php echo e(asset('css/datepicker.css')); ?>" rel="stylesheet">
<style>
    #sp .multi-select-button, #sp1 .multi-select-button{
        background: #eceeef;
    }
</style>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <strong><?php echo e(trans('labels.create_activity_achieved')); ?></strong>&nbsp;&nbsp;
                <a href="<?php echo e(url('/activity-achieve')); ?>" class="text-success"><i class="fa fa-arrow-left"></i> <?php echo e(trans('labels.back')); ?></a>
            </div>
            <div class="card-block">
                <?php if(Session::has('sms')): ?>
                    <div class="alert alert-success" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <div>
                            <?php echo e(session('sms')); ?>

                        </div>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('sms1')): ?>
                    <div class="alert alert-danger" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <div>
                            <?php echo e(session('sms1')); ?>

                        </div>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(url('/activity-achieve/save')); ?>" class="form-horizontal" method="post" onsubmit="return confirm('You want to save?')" name='frm'>
                    <?php echo e(csrf_field()); ?>

                    
                        
                            
                                
                            
                        
                    
                    <div class="row">
                        <div class="col-sm-6 <?php echo e(Auth::user()->ngo_id>0?'hide':''); ?>">
                             <div class="form-group row">
                                <label for="ngo" class="control-label col-sm-4 lb"><?php echo e(trans('labels.user_ngo')); ?> <span class="text-danger">*</span></label>
                                <div class="col-sm-8">
                                    <select name="ngo" id="ngo" class="form-control chosen-select" onchange="binding()">
                                    <?php $__currentLoopData = $ngos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ngo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ngo->id); ?>"><?php echo e($ngo->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                            
                                
                                
                                    
                                        
                                    
                                
                            
                        
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group row">
                                <label for="project_name" class="control-label col-sm-2 lb"><?php echo e(trans('labels.project_name')); ?></label>
                                <div class="col-sm-10">
                                    <select name="project_name" id="project_name" class="form-control chosen-select">
                                    
                                </select>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group row">
                                <label for="activity_name" class="control-label col-sm-2 lb"><?php echo e(trans('labels.activity_name')); ?></label>
                                <div class="col-sm-10">
                                    <select name="activity_name" id="activity_name" class="form-control chosen-select">
                                        <option value="0">-- <?php echo e(trans('labels.activity_name')); ?> --</option>
                                    </select>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12"></div>
                    </div>
                    <div class="row">

                        <div class="col-sm-6">

                           <div class="form-group row">
                                <label for="result_framework_structure" class="control-label col-sm-4 lb"><?php echo e(trans('labels.result_framework_structure')); ?></label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="result_framework_structure" name="result_framework_structure" disabled>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="component_responsible" class="control-label col-sm-4 lb"><?php echo e(trans('labels.component_responsible')); ?></label>
                                <div class="col-sm-8" id="sp">
                                    <select name="component_responsible[]" id="component_responsible" class="form-control" multiple disabled>

                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="person_responsible" class="control-label col-sm-4 lb"><?php echo e(trans('labels.person_responsible')); ?></label>
                                <div class="col-sm-8" id="sp1">
                                    <select name="person_responsible[]" id="person_responsible" class="form-control" multiple>

                                    </select>
                                </div>
                            </div>

                           <div class="form-group row">
                                <label for="person_achieved" class="control-label col-sm-4 lb"><?php echo e(trans('labels.person_achieved_activity')); ?></label>
                                <div class="col-sm-8" id="sp2">
                                    <select name="person_achieved[]" id="person_achieved" class="form-control" multiple>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($per->id); ?>"><?php echo e($per->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                        </div>
                        <div class="col-sm-6">
                            <div class="form-group row">
                                <label for="start_date" class="control-label col-sm-4 lb"><?php echo e(trans('labels.start_date')); ?></label>
                                <div class="col-sm-8">
                                    <input type="text"  placeholder="yyyy-mm-dd"  class="form-control datepicker-icon" id="start_date" name="start_date" value="<?php echo e(old('start_date')); ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="end_date" class="control-label col-sm-4 lb"><?php echo e(trans('labels.end_date')); ?></label>
                                <div class="col-sm-8">
                                   <input type="text" class="form-control datepicker-icon" placeholder="yyyy-mm-dd" id="end_date" name="end_date" value="<?php echo e(old('end_date')); ?>">
                                </div>
                            </div>
                            

                            <div class="form-group row">
                                <label for="actual" class="control-label col-sm-4 lb"><?php echo e(trans('labels.actual')); ?></label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" value="<?php echo e(old('actual')); ?>" id="actual" name="actual" placeholder="Input actual">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="activity_category" class="control-label col-sm-4 lb"><?php echo e(trans('labels.activity_category')); ?></label>
                                <div class="col-sm-8">
                                    <select name="activity_category" id="activity_category" class="form-control chosen-select" data-placeholder=" ">
                                        <option value="0">-- <?php echo e(trans('labels.none_select')); ?> --</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="venue" class="control-label lb col-sm-4">Venue</label>
                                <div class="col-sm-8">
                                    <select name="venue" id="venue" class="form-control">
                                        <option value="">Please select one</option>
                                        <?php $__currentLoopData = $venues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>                  
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <p class="text-center">
                            <br>
                                <button class="btn btn-primary btn-flat" type="submit"><?php echo e(trans('labels.save')); ?></button>
                                <button class="btn btn-success btn-flat" type="button" id="btnSaveGo">Save and Continue</button>
                                <input type="hidden" id="save_status" name="save_status" value="0">
                                <button class="btn btn-danger btn-flat" type="reset"><?php echo e(trans('labels.cancel')); ?></button>
                            </p>
                        </div>
                    </div>
                     <div class="row">
                        <div class="col-sm-12">
                            <p class="text-success">
                            All fields with <span class="text-danger">*</span> are required!
                            </p>
                        </div>
                    </div>
                </form>
               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/multiselect/jquery.multi-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            // save and continue
            $("#btnSaveGo").click(function () {
                var o = confirm('You want to save change?');
                if (o)
                {
                    $("#save_status").val("1");
                    frm.submit();
                }
            });
            $("#siderbar li a").removeClass("current");
            $("#menu_activity_achieved").addClass("current");
            $('#person_responsible').multiSelect();
            $("#component_responsible").multiSelect();
            $("#person_achieved").multiSelect();
            $("#start_date, #end_date").datepicker({
                orientation: 'bottom',
                format: 'yyyy-mm-dd',
                autoclose: true,
                todayHighlight: true,
                toggleActive: true
            });
            binding();
            $('#project_name').change(function(){
                $("#result_framework_structure").val("");
                bindActivity($("#ngo").val());
            });
            $("#activity_name").change(function(){
                $("#result_framework_structure").val("");
                bindFramework();
                bindComponent();
                bindPerson();
            });
        });
        // function binding data on ngo changed
        function binding()
        {
            var id = $("#ngo").val();
            $("#result_framework_structure").val("");
            bindProject(id);
            bindCategory(id);
        }
       
        // bind activity type
        function bindProject(ngo_id)
        {
            $.ajax({
                type: "GET",
                url: burl + "/ngo-project/get/" + ngo_id,
                success: function(sms){
                    var opts = "";
                    for(var i=0;i<sms.length;i++)
                    {
                        opts += "<option value='" + sms[i].id + "'>" + sms[i].project_code + " : " + sms[i].project_name + "</option>";
                    }
                     //$('#activity_type').val('').trigger('chosen:updated');  
                    $('#project_name').chosen('destroy');
                    $("#project_name").html(opts);
                    $("#project_name option:first-child").attr("selected","selected");
                    $('#project_name').chosen();

                    bindActivity(ngo_id);
                }
            });
        }
        // bind framework
        function bindActivity(ngo_id)
        {
           var aid = $("#project_name").val();
           $.ajax({
                type: "GET",
                url: burl + "/setting/get/" + ngo_id+"*"+aid,
                success: function(sms){
                    var opts = "";
                    for(var i=0;i<sms.length;i++)
                    {
                        opts += "<option value='" + sms[i].id + "'>" + sms[i].activity_code + " : " + sms[i].activity_name + "</option>";
                    }
                     //$('#activity_type').val('').trigger('chosen:updated');  
                    $('#activity_name').chosen('destroy');
                    // $("#activity_name").html("");
                    $("#activity_name").html(opts);
                    $("#activity_name option:first-child").attr("selected","selected");
                    $('#activity_name').chosen();                 
                    bindFramework();
                    bindComponent();
                    bindPerson();
                }
            });
        }
        function bindFramework()
        {
           var id = $("#activity_name").val();
           $.ajax({
                type: "GET",
                url: burl + "/setting/framework/get/" + id,
                success: function(sms){
                    
                    for(var i=0;i<sms.length;i++)
                    {
                        $("#result_framework_structure").val(sms[i].fname);
                    }
                }
            });
        }
        // bind component
        function bindComponent()
        {
            var id = $("#activity_name").val();
            $.ajax({
                type: "GET",
                url: burl + "/setting/component/get/" + id,
                success: function(sms){
                    var opts = "<select class='form-control' name='component_responsible[]' id='component_responsible' multiple disabled>";
                    for(var i=0;i<sms.length;i++)
                    {
                        opts += "<option value='" + sms[i].id + "' selected>" + sms[i].name + "</option>";
                    }
                    opts += "</select>";
                    $("#sp").html(opts);
                    $("#component_responsible").multiSelect();

                }
            });
        }
         function bindPerson()
        {
            var id = $("#activity_name").val();
            $.ajax({
                type: "GET",
                url: burl + "/setting/person/get/" + id,
                success: function(sms){
                    var opts = "<select class='form-control' name='person_responsible[]' id='person_responsible' multiple disabled>";
                    for(var i=0;i<sms.length;i++)
                    {
                        opts += "<option value='" + sms[i].id + "' selected>" + sms[i].name + "</option>";
                    }
                    opts += "</select>";
                    $("#sp1").html(opts);
                    $("#person_responsible").multiSelect();

                }
            });
        }
         function bindCategory(ngo_id)
        {
            $.ajax({
                type: "GET",
                url: burl + "/setting/category/get/" + ngo_id,
                success: function(sms){
                    var opts = "";
                    for(var i=0;i<sms.length;i++)
                    {
                        opts += "<option value='" + sms[i].id + "'>" + sms[i].name + "</option>";
                    }
                    $('#activity_category').chosen('destroy');
                    $("#activity_category").html(opts);
                    $("#activity_category option:first-child").attr("selected","selected");
                    $('#activity_category').chosen();                 

                }
            });
        }
        // bind component
        function bindUser(ngo_id)
        {
            $.ajax({
                type: "GET",
                url: burl + "/user/get/" + ngo_id,
                success: function(sms){
                    var lbs = "";
                    for(var i=0;i<sms.length;i++)
                    {
                        lbs += "<label class='multi-select-menuitem' for='person_responsible_" + i + "' role='menuitem'>";
                        lbs += "<input id='person_responsible_" + i + "' value='" + sms[i].id + "' type='checkbox'>";
                        lbs += sms[i].name;
                        lbs += "</label>";
                    }
                    $("#sp1 .multi-select-menuitems").html(lbs);
                   
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.achieve", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>