<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <div class="row">
                       <div class="col-sm-4">
                            <strong>Activity Achieved</strong>&nbsp;&nbsp;
                            <a href="<?php echo e(url('/activity-achieve/create')); ?>"><i class="fa fa-plus"></i> New</a>
                       </div>
                       <div class="col-sm-8">
                            <form action="" method="get" name="search">
                                <select name="user_ngo" id="user_ngo" class="chosen-select">
                                    <?php $__currentLoopData = $ngos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ngo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ngo->id); ?>"><?php echo e($ngo->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="filter">Filter</button>   
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card-block">
                    <table class="tbl">
                        <thead>
                        <tr>
                            <th>&numero;</th>
                            <th>Activity Name</th>
                            <th>Activity Type</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Total Budget</th>
                            <th>Total Expense</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            $pagex = @$_GET['page'];
                            if(!$pagex)
                                $pagex = 1;
                            $i = 12 * ($pagex - 1) + 1;
                        ?>
                        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><a href="<?php echo e(url('/activity-achieve/edit/'.$a->id)); ?>"><?php echo e($a->activity_name); ?></a></td>
                                <td><?php echo e($a->activity_type_name); ?></td>
                                <td><?php echo e($a->start_date); ?></td>
                                <td><?php echo e($a->end_date); ?></td>       
                                <td>$ <?php echo e($a->total_budget); ?></td>   
                                <td>$ <?php echo e($a->total_expense); ?></td>                      
                                <td>
                                    <a href="<?php echo e(url('/activity-achieve/edit/'.$a->id)); ?>" title="Edit"><i class="fa fa-edit text-success"></i></a>&nbsp;&nbsp
                                    <a href="<?php echo e(url('/activity-achieve/delete/'.$a->id ."?page=".@$_GET["page"])); ?>" onclick="return confirm('You want to delete?')"
                                       title="Delete"><i class="fa fa-remove text-danger"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <nav>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#menu_activity_achieved").addClass("current");
        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.activity', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>