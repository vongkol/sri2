<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <strong><?php echo e(trans('labels.ngo_list')); ?></strong>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/ngo/create')); ?>"><i class="fa fa-plus"></i> <?php echo e(trans('labels.new')); ?></a>
                </div>
                <div class="card-block">
                    <table class="tbl">
                        <thead>
                        <tr>
                            <th><?php echo trans('labels.id'); ?></th>
                            <th><?php echo e(trans('labels.organization_name')); ?></th>
                            <th><?php echo e(trans('labels.focal_person_name')); ?></th>
                            <th><?php echo e(trans('labels.focal_person_gender')); ?></th>
                            <th><?php echo e(trans('labels.focal_person_phone')); ?></th>
                            <th><?php echo e(trans('labels.organization_type')); ?></th>
                            <th><?php echo e(trans('labels.office_phone')); ?></th>
                            <th><?php echo e(trans('labels.office_email')); ?></th>
                            <th><?php echo e(trans('labels.office_based')); ?></th>
                            <th><?php echo e(trans('labels.actions')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            $pagex = @$_GET['page'];
                            if(!$pagex)
                                $pagex = 1;
                            $i = 12 * ($pagex - 1) + 1;
                        ?>
                        <?php $__currentLoopData = $ngos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ngo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/ngo/detail/'.$ngo->id)); ?>"><?php echo e($ngo->name); ?></a>
                                </td>
                                <td><?php echo e($ngo->person_name); ?></td>
                                <td><?php echo e($ngo->gender); ?></td>
                                <td><?php echo e($ngo->person_phone); ?></td>
                                <td><?php echo e($ngo->type); ?></td>
                                <td><?php echo e($ngo->phone); ?></td>
                                <td><?php echo e($ngo->email); ?></td>
                                <td><?php echo e($ngo->base); ?></td>
                                <td>
                                    <a class="btn btn-success btn-sm btn-flat my-btn" href="<?php echo e(url('/ngo/edit/'.$ngo->id)); ?>" title="Edit"><?php echo e(trans('labels.edit')); ?></a>
                                    <a class="btn btn-danger btn-sm btn-flat my-btn" href="<?php echo e(url('/ngo/delete/'.$ngo->id ."?page=".@$_GET["page"])); ?>" onclick="return confirm('You want to delete?')"
                                       title="Delete"><?php echo e(trans('labels.delete')); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <nav>
                        <?php echo e($ngos->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#menu_ngo").addClass("current");
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.setting", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>