<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <strong>Indicator Setting List</strong>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/indicator/create')); ?>"><i class="fa fa-plus"></i> New</a>
                </div>
                <div class="card-block">
                    <table class="tbl">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Project Code</th>
                            <th>Project Name</th>
                            <th>Indicator Code</th>
                            <th>Indicator Name</th>
                            <th>Indicator Level</th>
                            <th>Baseline</th>
                            <th>Data Source</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            $pagex = @$_GET['page'];
                            if(!$pagex)
                                $pagex = 1;
                            $i = 12 * ($pagex - 1) + 1;
                        ?>
                            <?php $__currentLoopData = $indicator_settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indicator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($indicator->id); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/indicator/edit/'.$indicator->id)); ?>"><?php echo e($indicator->project_code); ?></a>
                                </td>
                                <td>
                                    <a href="<?php echo e(url('/indicator/edit/'.$indicator->id)); ?>"><?php echo e($indicator->project_name); ?></a>
                                </td>
                                <td><?php echo e($indicator->indicator_code); ?></td>
                                <td><?php echo e($indicator->indicator_name); ?></td>
                                <td><?php echo e($indicator->indicator_level); ?></td>
                                <td><?php echo e($indicator->baseline); ?></td>
                                <td><?php echo e($indicator->data_source); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/indicator/edit/'.$indicator->id)); ?>" title="Edit"><i class="fa fa-edit text-success"></i></a>&nbsp;&nbsp
                                    <a href="<?php echo e(url('/indicator/delete/'.$indicator->id ."?page=".@$_GET["page"])); ?>" onclick="return confirm('You want to delete?')"
                                       title="Delete"><i class="fa fa-remove text-danger"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <nav>
                        <?php echo e($indicator_settings->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#menu_indicator_setting").addClass("current");
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.activity", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>