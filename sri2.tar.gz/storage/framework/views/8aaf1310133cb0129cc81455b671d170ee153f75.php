<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <div class="row">
                        <div class="col-sm-4">
                            <strong>Indicator Setting List</strong>&nbsp;&nbsp;
                            <a href="<?php echo e(url('/indicator/create')); ?>"><i class="fa fa-plus"></i> New</a>
                        </div>
                        <div class="col-sm-8">
                            <form action="" method="get" name="search">
                                <select name="user_ngo" id="user_ngo" class="chosen-select">
                                    <?php $__currentLoopData = $ngos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ngo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ngo->id); ?>"><?php echo e($ngo->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="filter">Filter</button>   
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card-block">
                    <table class="tbl">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Project Code</th>
                            <th>Project Name</th>
                            <th>Indicator Code</th>
                            <th>Indicator Name</th>
                            <th>Indicator Type</th>
                            <th>Baseline</th>
                            <th>Data Source</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            $pagex = @$_GET['page'];
                            if(!$pagex)
                                $pagex = 1;
                            $i = 12 * ($pagex - 1) + 1;
                        ?>
                            <?php $__currentLoopData = $indicator_settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indicator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/indicator/edit/'.$indicator->id)); ?>"><?php echo e($indicator->project_code); ?></a>
                                </td>
                                <td>
                                    <a href="<?php echo e(url('/indicator/edit/'.$indicator->id)); ?>"><?php echo e($indicator->project_name); ?></a>
                                </td>
                                <td><?php echo e($indicator->indicator_code); ?></td>
                                <td><?php echo e($indicator->indicator_name); ?></td>
                                <td><?php echo e($indicator->type); ?></td>
                                <td><?php echo e($indicator->baseline); ?></td>
                                <td><?php echo e($indicator->data_source); ?></td>
                                <td>
                                    <a class="btn btn-sm btn-success"​​ href="<?php echo e(url('/indicator/edit/'.$indicator->id)); ?>" title="Edit"><i class="fa fa-pencil"></i> Edit</a>&nbsp;&nbsp
                                    <a class="btn btn-sm btn-danger" href="<?php echo e(url('/indicator/delete/'.$indicator->id ."?page=".@$_GET["page"])); ?>" onclick="return confirm('You want to delete?')"
                                       title="Delete"><i class="fa fa-trash-o"></i> Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <nav>
                        <?php echo e($indicator_settings->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#menu_indicator_setting").addClass("current");
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.activity", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>