<?php $__env->startSection("content"); ?>
    <div class="row">
        <div class="col-sm-12">
            <h2 class="text-primary">Asset Management</h2>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.asset", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>