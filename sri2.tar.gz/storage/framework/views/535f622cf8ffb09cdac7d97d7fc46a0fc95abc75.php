<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <strong><?php echo e(trans('labels.create_ngo')); ?></strong>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/ngo')); ?>" class="text-success"><i class="fa fa-arrow-left"></i> <?php echo e(trans('labels.back')); ?></a>

                </div>
                <div class="card-block">
                    <?php if(Session::has('sms')): ?>
                        <div class="alert alert-success" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('sms1')): ?>
                        <div class="alert alert-danger" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms1')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(url('/ngo/save')); ?>" class="form-horizontal" method="post" enctype="multipart/form-data" onsubmit="return confirm('You want to save?')">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group row">
                                    <label  class="control-label col-sm-4 lb"><?php echo e(trans('labels.focal_person_name')); ?> <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="person_name" required >
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label  class="control-label col-sm-4 lb"><?php echo e(trans('labels.focal_person_gender')); ?></label>
                                    <div class="col-sm-8">
                                        <select name="gender" id="gender" class="form-control">
                                                <option value="Male"><?php echo e(trans('labels.male')); ?> </option>
                                                <option value="Female"><?php echo e(trans('labels.female')); ?> </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="control-label col-sm-4 lb"><?php echo e(trans('labels.focal_person_phone')); ?></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="person_phone">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="control-label col-sm-4 lb"><?php echo e(trans('labels.focal_person_position')); ?>​</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="person_position">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="control-label col-sm-4 lb"><?php echo e(trans('labels.focal_person_email')); ?></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="person_email">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="control-label col-sm-4 lb"><?php echo e(trans('labels.organization_name')); ?> <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="name" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="control-label col-sm-4 lb"><?php echo e(trans('labels.organization_acronym')); ?></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="acronym">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="control-label col-sm-4 lb"><?php echo e(trans('labels.organization_type')); ?></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="type"> 
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="control-label col-sm-4 lb"><?php echo e(trans('labels.office_phone')); ?></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="phone">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="control-label col-sm-4 lb"><?php echo e(trans('labels.office_email')); ?></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="email">
                                    </div>
                                </div>
                                <p class="text-success">
                                    <br>
                                    All fields with <span class="text-danger">*</span> are required!
                                </p>
                            </div>
                            <div class="col-sm-6">
                            
                                <div class="form-group row">
                                    <label class="control-label col-sm-3 lb"><?php echo e(trans('labels.sector')); ?></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="sector">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="control-label col-sm-3 lb"><?php echo e(trans('labels.office_based')); ?></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="base">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="logo" class="control-label col-sm-3 lb"><?php echo e(trans('labels.logo')); ?></label>
                                    <div class="col-sm-8">
                                        <input type="file" class="form-control" id="logo" name="logo" onchange="loadFile(event)">
                                        <br>
                                        <img src="<?php echo e(asset("uploads/ngos/default.png")); ?>" alt="Logo" width="120" id="preview">
                                        <p>
                                            <br>
                                            <button class="btn btn-primary btn-flat" type="submit"><?php echo e(trans('labels.save')); ?></button>
                                            <button class="btn btn-danger btn-flat" type="reset"><?php echo e(trans('labels.cancel')); ?></button>
                                        </p>
                                    </div>
                                </div>
                                    
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function loadFile(e){
            var output = document.getElementById('preview');
            output.src = URL.createObjectURL(e.target.files[0]);
        }
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#menu_ngo").addClass("current");
        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.setting", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>