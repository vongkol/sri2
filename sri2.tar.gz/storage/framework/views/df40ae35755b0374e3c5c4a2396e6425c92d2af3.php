<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <strong>New User</strong>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/user')); ?>" class="text-success"><i class="fa fa-arrow-left"></i> Back</a>
                </div>
                <div class="card-block">
                   <div class="row">
                       <div class="col-lg-9 col-md-12 col-sm-12">
                           <?php if(Session::has('sms')): ?>
                               <div class="alert alert-success" role="alert">
                                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                   </button>
                                   <div>
                                       <?php echo e(session('sms')); ?>

                                   </div>
                               </div>
                           <?php endif; ?>
                           <?php if(Session::has('sms1')): ?>
                               <div class="alert alert-danger" role="alert">
                                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                   </button>
                                   <div>
                                       <?php echo e(session('sms1')); ?>

                                   </div>
                               </div>
                           <?php endif; ?>
                           <form action="<?php echo e(url('/user/save')); ?>" enctype="multipart/form-data" method="post" id="frm" class="form-horizontal">
                               <?php echo e(csrf_field()); ?>

                               <div class="row">
                                   <div class="col">
                                       <div class="form-group row">
                                           <label for="name" class="control-label col-sm-4 lb">Username <span class="text-danger">*</span></label>
                                           <div class="col-sm-8">
                                               <input type="text" id="name" name="name" class="form-control" required>
                                           </div>
                                       </div>
                                   </div>
                                   <div class="col">
                                       <div class="form-group row">
                                           <label for="language" class="control-label col-sm-4 lb">Language <span class="text-danger">*</span></label>
                                           <div class="col-sm-8">
                                               <select name="language" id="language" class="form-control sl">
                                                   <option value="kh">ខ្មែរ</option>
                                                   <option value="en">English</option>
                                               </select>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <div class="row">
                                   <div class="col">
                                       <div class="form-group row">
                                           <label for="email" class="control-label col-sm-4 lb">Email <span class="text-danger">*</span></label>
                                           <div class="col-sm-8">
                                               <input type="email" required name="email" id="email" class="form-control">
                                           </div>
                                       </div>
                                   </div>
                                   <div class="col">
                                       <div class="form-group row">
                                           <label for="role" class="control-label col-sm-4 lb">Role <span class="text-danger">*</span></label>
                                           <div class="col-sm-8">
                                               <select name="role" id="role" class="form-control sl">
                                                   <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                       <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               </select>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <div class="row">
                                   <div class="col">
                                       <div class="form-group row">
                                           <label for="password" class="control-label col-sm-4 lb">Password <span class="text-danger">*</span></label>
                                           <div class="col-sm-8">
                                               <input type="password" required name="password" id="password" class="form-control">
                                               <br>
                                               <button class="btn btn-primary btn-flat" type="submit">Save</button>
                                               <button class="btn btn-danger btn-flat" type="reset" id="btnCancel">Cancel</button>
                                           </div>
                                       </div>
                                   </div>
                                   <div class="col">
                                       <div class="form-group row">
                                           <label for="photo" class="control-label col-sm-4 lb">Photo</label>
                                           <div class="col-sm-8">
                                               <input type="file" value="" name="photo" id="photo" class="form-control" onchange="loadFile(event)">
                                               <br>
                                               <img src="<?php echo e(asset('profile/default.png')); ?>" alt="" width="72" id="preview">
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <div class="row">
                                   <div class="col">
                                       <div class="form-group row">
                                           <label class="control-label col-sm-4 lb">&nbsp;</label>
                                           <div class="col-sm-8">

                                           </div>
                                       </div>
                                   </div>
                               </div>
                           </form>
                       </div>
                   </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function loadFile(e){
            var output = document.getElementById('preview');
            output.src = URL.createObjectURL(e.target.files[0]);
        }
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#user").addClass("current");
        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.setting", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>