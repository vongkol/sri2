
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="card-header text-bold">
                    <strong>Reset Your Password [<?php echo e(Auth::user()->email); ?>]</strong>&nbsp;&nbsp;
                </div>
                <div class="card-block">
                    <div class="row">
                        <div class="col-sm-12">
                            <?php if(Session::has('sms')): ?>
                                <div class="alert alert-success" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <div>
                                        <?php echo e(session('sms')); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('sms1')): ?>
                                <div class="alert alert-danger" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <div>
                                        <?php echo e(session('sms1')); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                                <form action="<?php echo e(url('/user/change-password')); ?>" class="form-horizontal" method="post">
                                <?php echo e(csrf_field()); ?>

                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group row">
                                                <label for="new_password" class="control-label col-sm-4">New Password</label>
                                                <div class="col-sm-8">
                                                    <input type="password" required  name="new_password" value="<?php echo e(old('new_password')); ?>" id="new_password" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col"></div>
                                    </div>
                                    <div class="row">
                                       <div class="col">
                                           <div class="form-group row">
                                               <label for="confirm_password" class="control-label col-sm-4">Confirm Password</label>
                                               <div class="col-sm-8">
                                                   <input type="password" required  name="confirm_password" value="<?php echo e(old('confirm_password')); ?>"
                                                          id="confirm_password" class="form-control">
                                               </div>
                                           </div>
                                       </div>
                                        <div class="col">

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group row">
                                                <label class="control-label col-sm-4">&nbsp;</label>
                                                <div class="col-sm-8">
                                                    <br>
                                                    <button class="btn btn-primary btn-flat" type="submit">Save</button>
                                                    <a href="<?php echo e(url('/user')); ?>" class="btn btn-danger btn-flat">Cancel</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col"></div>
                                    </div>
                                </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.setting', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>