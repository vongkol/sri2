<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <br>
            <h3 class='text-danger text-center'>You don't have permission to access this page. <br> <br>
                Please contact your system administrator!</h3>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.setting', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>