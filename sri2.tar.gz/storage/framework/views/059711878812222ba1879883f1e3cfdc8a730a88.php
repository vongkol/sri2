<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <div class="row">
                        <div class="col-sm-4">
                            <strong>Framework List</strong>&nbsp;&nbsp;
                            <a href="<?php echo e(url('/framework/create')); ?>"><i class="fa fa-plus"></i> New</a>
                        </div>
                        <div class="col-sm-8">
                            <form action="" method="get" name="search">
                                <select name="user_ngo" id="user_ngo" class="chosen-select">
                                    <option value="0">All NGOs</option>
                                    <option value="1">Vdoo Solutions Co., Ltd</option>
                                    <option value="0">Passerelles numeriques Cambodia</option>
                                </select>
                                <button type="submit" class="filter">Filter</button>   
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card-block">
                    <table class="tbl">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>NGO Name</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php
                                $pagex = @$_GET['page'];
                                if(!$pagex)
                                    $pagex = 1;
                                $i = 12 * ($pagex - 1) + 1;
                            ?>
                            <?php $__currentLoopData = $frameworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $framework): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($framework->name); ?></td>
                                    <td><?php echo e($framework->ngo_name==null?'CCC':$framework->ngo_name); ?></td>
                                    <td>
                                        <a class="btn btn-success btn-sm" href="<?php echo e(url('/framework/edit/'.$framework->id)); ?>" title="Edit"><i class="fa fa-pencil"></i> Edit</a>
                                        <a class="btn btn-danger btn-sm" href="<?php echo e(url('/framework/delete/'.$framework->id ."?page=".@$_GET["page"])); ?>" onclick="return confirm('You want to delete?')"
                                        title="Delete"><i class="fa fa-trash-o"></i> Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <nav>
                        <?php echo e($frameworks->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#framework").addClass("current");
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.setting", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>