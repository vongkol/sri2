<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <strong>Edit Salesperson</strong>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/salesperson')); ?>" class="text-success"><i class="fa fa-arrow-left"></i> Back</a>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/salesperson/create')); ?>" class="text-info"><i class="fa fa-plus"></i> New</a>

                </div>
                <div class="card-block">
                    <?php if(Session::has('sms')): ?>
                        <div class="alert alert-success" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('sms1')): ?>
                        <div class="alert alert-danger" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms1')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(url('/salesperson/update')); ?>" class="form-horizontal" method="post" onsubmit="return confirm('Are you sure want to save changes?')">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" value="<?php echo e($salesperson->id); ?>" name="id">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group row">
                                    <label for="first_name" class="control-label col-sm-3 lb">First Name<span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e($salesperson->first_name); ?>" name="first_name" id="first_name" required>
                                    </div>
                                </div>
                               
                               <div class="form-group row">
                                    <label for="last_name" class="control-label col-sm-3 lb">Last Name<span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e($salesperson->last_name); ?>" name="last_name" id="last_name" required>
                                    </div>
                                </div>
                                 <div class="form-group row">
                                    <label for="gender" class="control-label col-sm-3 lb">Gender<span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <select name="gender" id="gender" class="form-control">
                                            <option value="Male" <?php echo e($salesperson->gender=='Male'?'selected':''); ?>>Male</option>
                                            <option value="Female" <?php echo e($salesperson->gender=='Female'?'selected':''); ?>>Female</option>
                                        </select>
                                    </div>
                                </div>
                                 <div class="form-group row">
                                    <label for="dob" class="control-label col-sm-3 lb">Date of Birth</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e($salesperson->dob); ?>" name="dob" id="dob">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="email" class="control-label col-sm-3 lb">Email</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e($salesperson->email); ?>" name="email" id="email">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="phone" class="control-label col-sm-3 lb">Phone</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e($salesperson->phone); ?>" name="phone" id="phone">
                                    </div>
                                </div>
                               
                                <div class="form-group row">
                                    <label for="branch_id" class="control-label col-sm-3 lb">Branch Name</label>
                                    <div class="col-sm-8">
                                        <select name="branch_id" id="branch_id" class="form-control">
                                        <option value="0">Select a branch</option>
                                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($branch->id); ?>" <?php echo e($salesperson->branch_id==$branch->id?'selected':''); ?>><?php echo e($branch->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                         <p>
                                            <br>
                                            <button class="btn btn-primary btn-flat" type="submit">Save</button>
                                            <button class="btn btn-danger btn-flat" type="reset">Cancel</button>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("chosen/chosen.jquery.js")); ?>"></script>
    <script src="<?php echo e(asset("chosen/chosen.proto.js")); ?>"></script>
    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#salesperson").addClass("current");
            
        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>