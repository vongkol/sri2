<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <strong>Profile [<?php echo e(Auth::user()->email); ?>]</strong>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/user/edit/'.$user->id)); ?>" class="text-danger"><i class="fa fa-pencil"></i> Edit</a>
                </div>
                <div class="card-block">
                   <div class="row">
                       <div class="col-sm-6">
                           <div class="form-group row">
                               <label for="name" class="control-label col-sm-3 lb">ID</label>
                               <div class="col-sm-8">
                                   <input type="text" class="form-control" value="<?php echo e($user->id); ?>" readonly>
                               </div>
                           </div>
                           <div class="form-group row">
                               <label for="username" class="control-label col-sm-3 lb">Username</label>
                               <div class="col-sm-8">
                                   <input type="text" class="form-control" value="<?php echo e($user->name); ?>" readonly>
                               </div>
                           </div>
                           <div class="form-group row">
                               <label for="email" class="control-label col-sm-3 lb">Email</label>
                               <div class="col-sm-8">
                                   <input type="text" class="form-control" value="<?php echo e($user->email); ?>" readonly>
                               </div>
                           </div>
                           <div class="form-group row">
                               <label for="lang" class="control-label col-sm-3 lb">Language</label>
                               <div class="col-sm-8">
                                   <select name="lang" id="lang" class="form-control" readonly>
                                        <option value="en" <?php echo e($user->language=='en'?'selected':''); ?>>English</option>
                                        <option value="kh" <?php echo e($user->language=='kh'?'selected':''); ?>>Khmer</option>
                                   </select>

                               </div>
                           </div>
                           <div class="form-group row">
                               <label for="role" class="control-label col-sm-3 lb">Use Role</label>
                               <div class="col-sm-8">
                                   <select name="role" id="role" class="form-control" readonly>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($role->id); ?>" <?php echo e($role->id==$user->role_id?'selected':''); ?>><?php echo e($role->name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </select>

                               </div>
                           </div>
                       </div>
                       <div class="col-sm-6">
                           <div class="form-group row">
                               <img src="<?php echo e(asset('profile/'.$user->photo)); ?>" alt="Photo" width="160">
                           </div>
                       </div>
                       </div>
                   </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function loadFile(e){
            var output = document.getElementById('preview');
            output.src = URL.createObjectURL(e.target.files[0]);
        }
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#user").addClass("current");
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.setting", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>