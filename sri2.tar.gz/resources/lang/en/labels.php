<?php

return [


    'logout' => 'Logout',
    'ngo' => 'NGO',
    'home' => "Home",
    "activity" => "Activity",
    "help" => "Help",
    "administration" => "Administration",

    'profile' => "Profile",
    'reset_password' => "Reset Password"

];
