<?php

return [


    'logout' => 'ចាកចេញ',
    'ngo' => 'អង្គការ',
    'home' => "ទំព័រមុខ",
    "activity" => "សកម្មភាព",
    "help" => "ជំនួយ",
    "administration" => "ការគ្រប់គ្រង",
    'profile' => "ពត៌មានផ្ទាល់ខ្លួន",
    'reset_password' => 'ប្តូរលេខសម្ងាត់'

];
