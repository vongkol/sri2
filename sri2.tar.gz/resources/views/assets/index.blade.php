@extends("layouts.asset")
@section("content")
    <div class="row">
        <div class="col-sm-12">
            <h2 class="text-primary">Asset Management</h2>
        </div>
    </div>
@endsection