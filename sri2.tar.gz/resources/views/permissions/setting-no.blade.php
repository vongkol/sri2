@extends("layouts.setting")
@section('content')
<div class="row">
    <div class="col-sm-12">
        <h2 class="text-danger">You don't have permission to access this page. Please contact your system admin!</h2>
    </div>
</div>
@endsection