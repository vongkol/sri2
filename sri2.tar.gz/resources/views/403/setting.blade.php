@extends('layouts.setting')
@section('content')
    <div class="row">
        <div class="col-sm-12">
            <br>
            <h3 class='text-danger text-center'>You don't have permission to access this page. <br> <br>
                Please contact your system administrator!</h3>
        </div>

    </div>
@endsection