@extends('layouts.activity')
@section('content')
<h1>This is activity section!</h1>
@endsection