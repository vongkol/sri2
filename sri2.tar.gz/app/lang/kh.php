<?php
$lb_dashboard = "ផ្ទាំងពត៌មាន";
$lb_sale = "គ្រប់ក្រងការលក់";
$lb_pos = "គ្រប់គ្រង POS";
$lb_purchase = "គ្រប់គ្រងការជាវ";
$lb_inventory = "គ្រប់គ្រងទំនិញ";
$lb_accounting = "គណនេយ្យ";
$lb_setting = "កំណត់ត្រា";
$lb_help = "ជំនួយ";
$lb_profile = "Profile";
$lb_rest_password = "កែលេខសម្ងាត់";
$lb_logout = "ចូលប្រព័ន្ធ";
$lb_new = "បង្កើតថ្មី";
$lb_company = "ក្រុមហ៊ុន";
$lb_branch = "សាខា";
$lb_user = "អ្នកប្រើប្រាស់";
$lb_user_role = "តួនាទី";
